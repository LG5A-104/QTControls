#include "loginwindow.h"
#include "ui_loginwindow.h"

LoginWindow::LoginWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LoginWindow)
{
    ui->setupUi(this);

    my_window=new My_MainWindow;
    My_Connect();
    flags=1;
    ui->Register_button->setEnabled(false);
    ui->Name_lineEdit->setFocus();
    ui->Passwd_lineEdit_2->setEchoMode(QLineEdit::Password);
}

LoginWindow::~LoginWindow()
{
    delete ui;
}

void LoginWindow::My_Connect()
{
    QObject::connect(ui->pushButton_0,SIGNAL(clicked()),this,SLOT(Zero()));
    QObject::connect(ui->pushButton_1,SIGNAL(clicked()),this,SLOT(One()));
    QObject::connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(Two()));
    QObject::connect(ui->pushButton_3,SIGNAL(clicked()),this,SLOT(Three()));
    QObject::connect(ui->pushButton_4,SIGNAL(clicked()),this,SLOT(Four()));
    QObject::connect(ui->pushButton_5,SIGNAL(clicked()),this,SLOT(Five()));
    QObject::connect(ui->pushButton_6,SIGNAL(clicked()),this,SLOT(Six()));
    QObject::connect(ui->pushButton_7,SIGNAL(clicked()),this,SLOT(Seven()));
    QObject::connect(ui->pushButton_8,SIGNAL(clicked()),this,SLOT(Eight()));
    QObject::connect(ui->pushButton_9,SIGNAL(clicked()),this,SLOT(Nine()));
    QObject::connect(ui->pushButton_backspace,SIGNAL(clicked()),this,SLOT(Backspace()));
    QObject::connect(ui->pushButton_cancel,SIGNAL(clicked()),this,SLOT(Cancel()));
    QObject::connect(ui->pushButton_clear,SIGNAL(clicked()),this,SLOT(Clear()));
    QObject::connect(ui->pushButton_login,SIGNAL(clicked()),this,SLOT(Login()));
    QObject::connect(ui->pushButton_tab,SIGNAL(clicked()),this,SLOT(Tab()));
    QObject::connect(ui->Register_button,SIGNAL(clicked()),this,SLOT(My_Register()));
}


void LoginWindow::Tab(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setFocus();
        flags=1;
    }else if(flags==1)
    {
        ui->Name_lineEdit->setFocus();
        flags=0;
    }
}

void LoginWindow::Login()
{
    int f=check_name_passwd();
    my_window->showFullScreen();
//    switch(f)
//    {
//    case -1:QMessageBox::about(this,"Warning","user name or passwd is empty");break;
//    case 0:QMessageBox::about(this,"Warning","Open the passwd file is error");break;
//    case 1:my_window->showFullScreen();break;
//    case 2:QMessageBox::about(this,"Warning","Your input name or passwd is error , please input again");break;
//    }

}

void LoginWindow::Cancel()
{
    this->close();
}

void LoginWindow::Clear()
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->clear();
    }else if(flags==1)
    {
        ui->Name_lineEdit->clear();
    }
}

void LoginWindow::Backspace()
{
    if(flags==0)
    {

        QString str=ui->Passwd_lineEdit_2->text();
        int count1=str.length();
        if(count1>0)
        {
            str=str.mid(0,count1-1);
            ui->Passwd_lineEdit_2->setText(str);
        }
    }else if(flags==1)
    {
        QString str=ui->Name_lineEdit->text();
        int count2=str.length();
        if(count2>0)
        {
            str=str.mid(0,count2 -1);
            ui->Name_lineEdit->setText(str);
        }
    }
}

void LoginWindow::Zero(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"0");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"0");
    }
}

void LoginWindow::One(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"1");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"1");
    }

}

void LoginWindow::Two(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"2");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"2");
    }
}

void LoginWindow::Three(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"3");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"3");
    }
}

void LoginWindow::Four(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"4");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"4");
    }
}

void LoginWindow::Five(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"5");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"5");
    }
}

void LoginWindow::Six(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"6");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"6");
    }
}

void LoginWindow::Seven(void)
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"7");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"7");
    }

}

void LoginWindow::Eight()
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"8");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"8");
    }
}

void LoginWindow::Nine()
{
    if(flags==0)
    {
        ui->Passwd_lineEdit_2->setText(ui->Passwd_lineEdit_2->text()+"9");
    }else if(flags==1)
    {
        ui->Name_lineEdit->setText(ui->Name_lineEdit->text()+"9");
    }
}

int LoginWindow::check_name_passwd(void)
{
    QString name=ui->Name_lineEdit->text();
    QString passwd=ui->Passwd_lineEdit_2->text();
    if(NULL== name || NULL== passwd)
    {
        return -1;
    }

    std::string Str_name = name.toStdString();
    std::string Str_passwd=passwd.toStdString();

    const char *ch_name=Str_name.c_str();
    const char *ch_passwd=Str_passwd.c_str();

    char fp_name[11];
    char fp_passwd[11];

    FILE *fp;
    fp=fopen("/root/passwd","r");
    if(NULL==fp)
    {
        ui->Register_button->setEnabled(true);
        return 0;
    }
    while((fscanf(fp,"%s %s",fp_name,fp_passwd))==2)
    {
        printf("%s %s",fp_name,fp_passwd);
        if((strcmp(ch_name,fp_name)==0) && (strcmp(ch_passwd,fp_passwd)==0))
        {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 2;
}

void LoginWindow::My_Register()
{
    FILE *fp;
    QString name=ui->Name_lineEdit->text();
    QString passwd=ui->Passwd_lineEdit_2->text();
    if( NULL == name || NULL == passwd)
    {
        QMessageBox::about(this,"Warning","User name or passwd is empty,please input again");
        return;
    }
    std::string Str_name = name.toStdString();
    std::string Str_passwd=passwd.toStdString();

    const char *ch_name=Str_name.c_str();
    const char *ch_passwd=Str_passwd.c_str();

    fp=fopen("/root/passwd","w");
    fprintf(fp,"%s %s",ch_name,ch_passwd);
    fclose(fp);
    ui->Register_button->setEnabled(false);
}

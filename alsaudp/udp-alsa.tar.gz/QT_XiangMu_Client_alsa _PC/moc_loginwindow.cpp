/****************************************************************************
** Meta object code from reading C++ file 'loginwindow.h'
**
** Created: Wed Apr 12 09:28:13 2017
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "loginwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'loginwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_LoginWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      20,   12,   12,   12, 0x0a,
      26,   12,   12,   12, 0x0a,
      32,   12,   12,   12, 0x0a,
      40,   12,   12,   12, 0x0a,
      47,   12,   12,   12, 0x0a,
      54,   12,   12,   12, 0x0a,
      60,   12,   12,   12, 0x0a,
      68,   12,   12,   12, 0x0a,
      76,   12,   12,   12, 0x0a,
      83,   12,   12,   12, 0x0a,
      91,   12,   12,   12, 0x0a,
     103,   12,   12,   12, 0x0a,
     111,   12,   12,   12, 0x0a,
     120,   12,   12,   12, 0x0a,
     126,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_LoginWindow[] = {
    "LoginWindow\0\0Zero()\0One()\0Two()\0Three()\0"
    "Four()\0Five()\0Six()\0Seven()\0Eight()\0"
    "Nine()\0Clear()\0Backspace()\0Login()\0"
    "Cancel()\0Tab()\0My_Register()\0"
};

void LoginWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        LoginWindow *_t = static_cast<LoginWindow *>(_o);
        switch (_id) {
        case 0: _t->Zero(); break;
        case 1: _t->One(); break;
        case 2: _t->Two(); break;
        case 3: _t->Three(); break;
        case 4: _t->Four(); break;
        case 5: _t->Five(); break;
        case 6: _t->Six(); break;
        case 7: _t->Seven(); break;
        case 8: _t->Eight(); break;
        case 9: _t->Nine(); break;
        case 10: _t->Clear(); break;
        case 11: _t->Backspace(); break;
        case 12: _t->Login(); break;
        case 13: _t->Cancel(); break;
        case 14: _t->Tab(); break;
        case 15: _t->My_Register(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData LoginWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject LoginWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_LoginWindow,
      qt_meta_data_LoginWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &LoginWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *LoginWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *LoginWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LoginWindow))
        return static_cast<void*>(const_cast< LoginWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int LoginWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

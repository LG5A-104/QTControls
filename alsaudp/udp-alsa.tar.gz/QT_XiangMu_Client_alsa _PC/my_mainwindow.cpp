#include "my_mainwindow.h"
#include "ui_my_mainwindow.h"

My_MainWindow::My_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::My_MainWindow)
{
    ui->setupUi(this);

    thread=new My_Thread;

    QObject::connect(thread,SIGNAL(shutdown_Myself()),this,SLOT(Restart_button()));
    QObject::connect(thread,SIGNAL(setId(int)),this,SLOT(setId(int)));
    QObject::connect(thread,SIGNAL(setRate(int)),this,SLOT(setRate(int)));
    QObject::connect(ui->Start_pushButton,SIGNAL(clicked()),this,SLOT(Start_button()));
    QObject::connect(ui->ReStart_pushButton,SIGNAL(clicked()),thread,SLOT(Stop_Fun()));
}

void My_MainWindow::setRate(int rate)
{
    ui->rate->setText(QString::number(rate));
}

void My_MainWindow::setId(int id)
{
    ui->id_label->setText(QString::number(id));
}

void My_MainWindow::Start_button()
{
    thread->Open_device();
    thread->start();

    ui->Start_pushButton->setEnabled(false);
 }

void My_MainWindow::Restart_button()
{
    ui->warning_label->setText("Something is wrong ,System is restarting");
     thread->terminate();
     sleep(2);
    system("/root/qt4");
    qApp->quit();
}

My_MainWindow::~My_MainWindow()
{
    delete ui;
}

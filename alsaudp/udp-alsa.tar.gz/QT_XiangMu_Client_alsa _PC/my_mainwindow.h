#ifndef MY_MAINWINDOW_H
#define MY_MAINWINDOW_H

#include <QMainWindow>
#include"my_thread.h"
namespace Ui {
class My_MainWindow;
}

class My_MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit My_MainWindow(QWidget *parent = 0);
    ~My_MainWindow();
public slots:
    void Start_button(void);

    void Restart_button(void);

    void setRate(int);
    void setId(int);


private:
    Ui::My_MainWindow *ui;
    My_Thread *thread;
};

#endif // MY_MAINWINDOW_H

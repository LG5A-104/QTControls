#include "my_network.h"
#include"user_info.h"

My_NetWork::My_NetWork()
{
    Port=8888;
    Ip="192.168.10.101";
}

bool My_NetWork::My_Socket()
{
    ch_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(ch_fd < 0)
    {
        perror("Create Socket is error \n");
        return false;
    }
    return true;
}

void My_NetWork::My_Init_Sock()
{
    memset(&serv,0,sizeof(struct sockaddr_in));
    serv.sin_family = AF_INET;
    serv.sin_port = htons(Port);
    inet_aton(Ip, &serv.sin_addr);

    int flag=1;
    setsockopt(ch_fd,IPPROTO_TCP,TCP_NODELAY,(char *)&flag,sizeof(flag));
    int nZero = 1024;
    setsockopt(ch_fd, SOL_SOCKET, SO_RCVBUF, ( char * )&nZero, sizeof( int ) );
    int r_Zero=0;
    setsockopt(ch_fd, SOL_SOCKET, SO_SNDBUF, ( char * )&r_Zero, sizeof( int) );
}

int My_NetWork::My_Connect()
{
    len = sizeof(serv);
    if(connect(ch_fd, (struct sockaddr *)&serv, len) == -1)
    {
        perror("Connect is Failered \n");
        return -1;
    }
    return ch_fd;
}


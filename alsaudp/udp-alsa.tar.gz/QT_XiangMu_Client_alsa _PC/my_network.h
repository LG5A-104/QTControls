#ifndef MY_NETWORK_H
#define MY_NETWORK_H
#include"user_info.h"
class My_NetWork
{
public:
    My_NetWork();
    bool My_Socket(void);
    void My_Init_Sock(void);
    int My_Connect(void);
private:
    int Port;
    char *Ip;
    int ch_fd;
    socklen_t len;
    struct sockaddr_in serv;
};

#endif // MY_NETWORK_H

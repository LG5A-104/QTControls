#include "my_thread.h"

My_Thread::My_Thread()
{
    maxd=0;
    ad_flags=1;
    id_flags=1;
    net=new My_NetWork;

}

void My_Thread::My_Recv(int my_socket ,void *p,int length)
{
    int l_message=length;
    char *r_p_message=(char *)p;
    int recv_data;
    while(1)
    {
        if(l_message>0)
        {
            recv_data=recv(my_socket,r_p_message,l_message,MSG_DONTWAIT);
            if(recv_data>0)
            {
                l_message-= recv_data;
                r_p_message+= recv_data;
            }else if(recv_data < 0)
            {
                if(errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
                {
                    continue;
                }else
                {
                    Stop_Fun();
                }
            }else if(0 == recv_data)
            {
                Stop_Fun();
            }
        }else
        {
            break;
        }
    }
}

void My_Thread::My_Send(int my_socket,void *p,int length)
{
    int l_message=length;
    char *p_message=(char *)p;
    int send_data;
    while(1)
    {
        if(l_message > 0)
        {
            send_data=send(my_socket,p_message,l_message,MSG_DONTWAIT);
            if(send_data>0)
            {
                l_message-= send_data;
                p_message+= send_data;
            }else if(send_data < 0)
            {
                if(errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
                {
                    continue;
                }else
                {
                    Stop_Fun();
                }

            }else if(0 == send_data)
            {
                Stop_Fun();
            }
        }else
        {
            break;
        }
    }
}

//bool My_Thread::My_Read_Sound()
//{
//    memset(&client_send_message.buff,0,sizeof(client_send_message.buff));
//    int buf_length=sizeof(client_send_message.buff);
//    unsigned char *buf_p=client_send_message.buff;
//    int sound_read=0;
//    while(1)
//    {
//        if(buf_length>0)
//        {
//            sound_read=read(sound_fd,buf_p,buf_length);
//            if(sound_read>0)
//            {
//                buf_length -= sound_read;
//                buf_p += sound_read;
//            }else if(sound_read<0)
//            {
//                perror("read sound error");
//                return false;
//            }
//        }else
//        {
//            return true;
//        }
//    }
//}


bool My_Thread::My_Read_Sound()
{
    printf("start recording\n");
    memset(&client_send_message.buff,0,sizeof(client_send_message.buff));
    int sound_read=0;
    sound_read = snd_pcm_readi(handle_send, client_send_message.buff,frames_send);
    if (sound_read == -EPIPE) {
        // EPIPE means overrun
        fprintf(stderr, "@ACap::Start()--overrun occurred CAP\n");
        snd_pcm_prepare(handle_send);
        return 0;
    } else if(sound_read < 0) {
        fprintf(stderr, "@ACap::Start()--error from read: %s\n", snd_strerror(sound_read));
        return 0;
    } else if(sound_read != (int)frames_send) {
        fprintf(stderr, "@ACap::Start()--short read, read %d frames\n", sound_read);
        return 0;
    }
    else
    {
        return true;
    }
}

bool My_Thread::My_Read_Adc()
{
    int tmp_adc_data;
    char buff[20];

    int ret = read(adc,buff,sizeof(buff));
    if(ret<0)
    {
        return false;
    }

    sscanf(buff,"%d",&tmp_adc_data);
    ad_value+=tmp_adc_data;
    ad_value /= 2;

    client_send_message.adc_data=ad_value;
    emit setRate(ad_value);

    return true;
}

void My_Thread::Init_Flags()
{
    c_s_flags.flags=0xaa;
    c_s_flags.length=sizeof(struct Cli_Message);
    memset(c_s_flags.buff,0,sizeof(c_s_flags.buff));
    c_r_flags.flags=0xaa;
    c_r_flags.length=sizeof(struct Cli_Message);
    memset(c_r_flags.buff,0,sizeof(c_r_flags.buff));

}

void My_Thread::Open_device()
{
    //Adc_Init();
//    Dsp_Init();
//    Dsp_Init_Send();
   //    Init_Flags();
}

void My_Thread::Stop_Fun()
{
    close(sound_fd);
    close(Socket);
    close(adc);

//    snd_pcm_drain(handle);
//    snd_pcm_close(handle);
//    snd_pcm_drain(handle_send);
//    snd_pcm_close(handle_send);


    emit shutdown_Myself();
}

void My_Thread::run()
{
    if(!net->My_Socket())
    {
        Stop_Fun();
    }
    net->My_Init_Sock();
    Socket=net->My_Connect();
    if(Socket == -1)
    {
        Stop_Fun();
        return;
    }

    while(1)
    {
        timeout.tv_sec=2;
        timeout.tv_usec=0;
        FD_ZERO(&readfd);
        FD_ZERO(&writefd);
        FD_SET(Socket,&readfd);
        FD_SET(Socket,&writefd);
        if(maxd<Socket)
        {
            maxd=Socket;
        }
        val=select(maxd+1,&readfd,&writefd,NULL,&timeout);
        switch(val)
        {
        case -1: break;
        case  0: break;
        default:

            if(FD_ISSET(Socket,&writefd))
            {
                Dsp_Init_Send();
                if(My_Read_Sound() && My_Read_Adc())
                {
                    memmove(c_s_flags.buff,"Sound",5);
                    My_Send(Socket,(void *)&c_s_flags,sizeof(struct d_flags));
                    My_Send(Socket,(void *)&client_send_message,sizeof(struct Cli_Message));
                }
                snd_pcm_drain(handle_send);
                snd_pcm_close(handle_send);
            }

            if(FD_ISSET(Socket,&readfd))
            {
                Dsp_Init();
                int rc;
                My_Recv(Socket,(void *)&c_r_flags,sizeof(struct d_flags));
                if(c_r_flags.flags==0xaa)
                {
                    My_Recv(Socket,(void *)&client_recv_message,sizeof(struct Cli_Message));
                    //printf("id=%d \n adc_data=%d\n",client_recv_message.client_number,client_recv_message.adc_data);
                    emit setId(client_recv_message.client_number);
                   // write(sound_fd,&client_recv_message.buff,sizeof(client_recv_message.buff));
                    //printf("write is here");
                    rc = snd_pcm_writei(handle,&client_recv_message.buff,frames/*/(snd_pcm_format_width(format)/8)*/);
                    printf("rc is :%d\n",rc);
                    if(rc == -EPIPE) {
                        // EPIPE means underrun
                        fprintf(stderr, "@APlayer::Start()--underrun occurred PALY\n");
                        snd_pcm_prepare(handle);
                    } else if(rc < 0) {
                        fprintf(stderr, "@APlayer::Start()--error from writei: %s\n", snd_strerror(rc));
                    }  else if(rc != (int)frames) {
                        fprintf(stderr, "@APlayer::Start()--short write, write %d frames\n", rc);
                    }
                }
                snd_pcm_drain(handle);
                snd_pcm_close(handle);
            }
        }
    }

}

void My_Thread::Adc_Init()
{
    int tmp_adc_data;
    char buff[20];

    adc=open("/dev/adc",O_RDWR);
    if(adc<0)
    {
        perror("Open adc is error");
        Stop_Fun();
    }

    int ret = read(adc,buff,sizeof(buff));
    if(ret<0)
    {
        return;
    }
    sscanf(buff,"%d",&tmp_adc_data);
    ad_value+=tmp_adc_data;
    printf("%d\n",ad_value);
}

void My_Thread::Dsp_Init()
{
    int r;
    char *pcm_name = strdup("hw:0,0");
    // Open PCM device for playback.
    r = snd_pcm_open(&handle, pcm_name, SND_PCM_STREAM_PLAYBACK, 0);
    if (r < 0) {
        fprintf(stderr, "@APlayer()--unable to open pcm device: %s\n", snd_strerror(r));
        exit(1);
    }
    printf("open device success\n");

    // Allocate a hardware parameters object
    snd_pcm_hw_params_alloca(&params);

    // Fill it in with default values.
    snd_pcm_hw_params_any(handle, params);

    // Set the desired hardware parameters.
    //  Interleaved mode
    snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);


//    snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_NONINTERLEAVED);

    // Signed 16-bit little-endian format
    snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_S16_LE);
//    snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_U8);

    // Two channels (stereo)
    snd_pcm_hw_params_set_channels(handle, params, 2);
//    snd_pcm_hw_params_set_channels(handle, params, 1);

    // 44100 bits/second sampling rate (CD quality)
    unsigned int  val = 44100;
//    unsigned int  val = 8000;
    int  dir;
    snd_pcm_hw_params_set_rate_near(handle, params, &val, &dir);

    // Set period size to 32 frames.
    frames = 128;
    snd_pcm_hw_params_set_period_size_near(handle, params, &frames, &dir);

    // Write the parameters to the driver
    r = snd_pcm_hw_params(handle, params);
    if (r < 0) {
        fprintf(stderr, "@APlayer()--unable to set hw param: %s\n", snd_strerror(r));
        exit(1);
    }
    printf("pei zhi cheng gong\n");

//    // Use a buffer large enough to hold one period
//   // snd_pcm_hw_params_get_period_size(params, &frames, &dir);
//    size = frames * 4;      // 2 bytes/sample, 2 channels
////    size = frames;      // 1 bytes/sample, 1 channels
//    buffer = (char *) malloc(size);

//    // We want to loop for 5 seconds
//    snd_pcm_hw_params_get_period_time(params, &period, &dir);
}


void My_Thread::Dsp_Init_Send()
{
    int r;
    char *pcm_name = strdup("hw:0,0");
    // Open PCM device for playback.
    r = snd_pcm_open(&handle_send, pcm_name, SND_PCM_STREAM_CAPTURE, 0);
    if (r < 0) {
        fprintf(stderr, "@APlayer()--unable to open pcm device: %s\n", snd_strerror(r));
        exit(1);
    }
    printf("open device success\n");

    // Allocate a hardware parameters object
    snd_pcm_hw_params_alloca(&params_send);

    // Fill it in with default values.
    snd_pcm_hw_params_any(handle_send, params_send);

    // Set the desired hardware parameters.
    //  Interleaved mode
    snd_pcm_hw_params_set_access(handle_send, params_send, SND_PCM_ACCESS_RW_INTERLEAVED);


//    snd_pcm_hw_params_set_access(handle, params, SND_PCM_ACCESS_RW_NONINTERLEAVED);

    // Signed 16-bit little-endian format
    snd_pcm_hw_params_set_format(handle_send, params_send, SND_PCM_FORMAT_S16_LE);
//    snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_U8);

    // Two channels (stereo)
    snd_pcm_hw_params_set_channels(handle_send, params_send, 2);
//    snd_pcm_hw_params_set_channels(handle, params, 1);

    // 44100 bits/second sampling rate (CD quality)
    unsigned int  val = 44100;
//    unsigned int  val = 8000;
    int  dir;
    snd_pcm_hw_params_set_rate_near(handle_send, params_send, &val, &dir);

    // Set period size to 32 frames.
    frames_send = 128;
    snd_pcm_hw_params_set_period_size_near(handle_send, params_send, &frames_send, &dir);

    // Write the parameters to the driver
    r = snd_pcm_hw_params(handle_send, params_send);
    if (r < 0) {
        fprintf(stderr, "@APlayer()--unable to set hw param: %s\n", snd_strerror(r));
        exit(1);
    }
    printf("pei zhi cheng gong\n");

//    // Use a buffer large enough to hold one period
//   // snd_pcm_hw_params_get_period_size(params, &frames, &dir);
//    size = frames * 4;      // 2 bytes/sample, 2 channels
////    size = frames;      // 1 bytes/sample, 1 channels
//    buffer = (char *) malloc(size);

//    // We want to loop for 5 seconds
//    snd_pcm_hw_params_get_period_time(params, &period, &dir);
}


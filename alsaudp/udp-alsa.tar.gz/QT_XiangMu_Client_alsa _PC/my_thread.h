#ifndef MY_THREAD_H
#define MY_THREAD_H

#include<QThread>
#include"user_info.h"
#include"my_network.h"
#define ALSA_PCM_NEW_HW_PARAMS_API
//#include <alsa/asoundlib.h>

class My_Thread:public QThread
{
     Q_OBJECT

public:
    My_Thread();
    void run();
    void Adc_Init(void);
    void Dsp_Init();
    void Dsp_Init_Send();

    void My_Recv(int my_socket,void *p,int length);
    void My_Send(int my_socket,void *p,int length);
    bool My_Read_Sound(void);
    void Init_Flags(void);
    void Open_device(void);
    bool My_Read_Adc(void);
public slots:
        void Stop_Fun(void);

signals:
        void shutdown_Myself(void);
        void setRate(int);
        void setId(int);

private:

    struct d_flags c_s_flags,c_r_flags;
    struct Cli_Message client_recv_message;
    struct Cli_Message client_send_message;

private:
    int sound_fd;	/* 声音设备的文件描述符 */
    int adc; //ADC
    int Socket;

private:  //select function
    timeval timeout;
    fd_set readfd,writefd;
    int maxd;
    int val;

private:
     int ad_value;
     int ad_flags;
private:
     int id_flags;
 private:
    My_NetWork *net;




public:

    snd_pcm_t  *handle;
    snd_pcm_hw_params_t  *params;
    snd_pcm_uframes_t  frames;
    char  *buffer;
    int  size;
    unsigned int  period;
    int buffer_count;
    snd_pcm_format_t format;


public:

    snd_pcm_t  *handle_send;
    snd_pcm_hw_params_t  *params_send;
    snd_pcm_uframes_t  frames_send;
    char  *buffer_send;
    int  size_send;
    unsigned int  period_send;
    int buffer_count_send;
    snd_pcm_format_t format_send;

};

#endif // MY_THREAD_H

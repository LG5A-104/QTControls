#include "udpform.h"
#include <QFile>


UDPForm::UDPForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UDPForm)
{
    ui->setupUi(this);
    initAlsaDevice();
    udpSocket = new QUdpSocket();
    udpSocket->bind(13930, QUdpSocket::ShareAddress);
    //udpSocket->bind(13930, QUdpSocket::DontShareAddress);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readPendingDatagrams()));
}

UDPForm::~UDPForm()
{
    delete ui;
    delete buffer;
    delete udpSocket;
    delete fp;
}

void UDPForm::on_pushButton_clicked()
{
    //QString data = tr("alsa project to network");
    QString data = ui->lineEdit->text();
    QHostAddress adr=QHostAddress("192.168.9.179");
    udpSocket->writeDatagram(data.toUtf8(), adr, 13930);
    //qDebug() << QHostAddress::Broadcast;
    //udpSocket->writeDatagram(data.toUtf8(), QHostAddress::LocalHost, 13930);
}

void UDPForm::readPendingDatagrams()
{
    while (udpSocket->hasPendingDatagrams()) {
           QByteArray datagram;
           // 不会存在粘包问题
           // pendingDatagramSize() returns the size of the first pending UDP datagram.
           // If there is no datagram available, this function returns -1.
           datagram.resize(udpSocket->pendingDatagramSize());
           udpSocket->readDatagram(datagram.data(), datagram.size());
           qDebug() << QString::fromUtf8(datagram);
           ui->textBrowser->append(QString::fromUtf8(datagram));
    }
}

void UDPForm::initAlsaDevice()
{

}

void UDPForm::on_pushButton_2_clicked()
{
    int i = 0;
    QHostAddress adr=QHostAddress("192.168.9.179");
    QFile file("dengziqi.wav");
    if(!file.open(QIODevice::ReadWrite)) {
        qDebug()<<tr("Can't open the file!");
    }
    memset(&wav_header,0,sizeof(struct WAV_HEADER));
    file_length = file.read((char*)&wav_header,sizeof(wav_header));
    qDebug() << tr("file_length")<<QString::number(file_length);

    /*malloc wav pcm data buffer*/
    dataSizeIn20ms = wav_header.nSamplesPersec * wav_header.wBlockAlign / 50;
    qDebug() << tr("dataSizeIn20ms")<<QString::number(dataSizeIn20ms);

    file.seek(sizeof(wav_header));
    while(!file.atEnd()) {
        QByteArray byte = file.read(dataSizeIn20ms);
        udpSocket->writeDatagram(byte, adr, 13930);
        usleep(17000);
        i++;
        qDebug()<<tr("wave package:")<<QString::number(i);
        qDebug()<<tr("dataSizeIn20ms:")<<QString::number(dataSizeIn20ms);
        qDebug()<<tr("byte size:")<<QString::number(byte.size());

    }
//    int err;
//    QByteArray byte;
//    QHostAddress adr=QHostAddress("192.168.9.179");
//    fp = fopen("dengziqi.wav","rw");
//    if (NULL == fp ) {
//          qDebug() <<tr("Error:open %s erro ,please check the WAV-File exist?\n");
//          return ;/* code */
//      }
//    memset(&wav_header,0,sizeof(struct WAV_HEADER));
//    file_length = fread(&wav_header, 1, sizeof(wav_header), fp);
//    /*malloc wav pcm data buffer*/
//    dataSizeIn20ms = wav_header.nSamplesPersec * wav_header.wBlockAlign / 50;
//    qDebug() << tr("dataSizeIn20ms")<<QString::number(dataSizeIn20ms);


//    //printf("dataSizeIn20ms = %d\n",dataSizeIn20ms);
//    buffer =(char*)malloc(dataSizeIn20ms);

//    /* seek to the sound data position */
//    fseek(fp, sizeof(wav_header), SEEK_SET);
//    int i = 0;
//    while(file_length)
//    {
//      i++;

//      memset(buffer, 0, dataSizeIn20ms);
//      file_length = fread(buffer, 1, dataSizeIn20ms, fp);
//      QByteArray byte(buffer);
//      usleep(200);
//      udpSocket->writeDatagram(byte, adr, 13930);
//      qDebug()<<tr("wave package:")<<QString::number(i);
//      qDebug()<<tr("dataSizeIn20ms:")<<QString::number(dataSizeIn20ms);
//      qDebug()<<tr("file_length :")<<QString::number(file_length);
//      qDebug()<<tr("byte size:")<<QString::number(byte.size());

//    }
//    fclose(fp);

    //fprintf (stdout, "audio PLAY successful\n");
    //snd_pcm_close (playback_handle);
}

#ifndef UDPFORM_H
#define UDPFORM_H

#include <QWidget>
#include <QUdpSocket>
#include "ui_udpform.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>

namespace Ui {
class UDPForm;
}
struct WAV_HEADER
{
  char rld[4];    // flag "RIFF"
  int rLen;       // file size
  char wld[4];    // flag "WAVE"
  char fld[4];    //"fmt "

  int fLen;   //sizeof(wave format matex)   20

  short wFormatTag;   //codec format
  short wChannels;    //channels
  int   nSamplesPersec ;  //samples rate
  int   nAvgBitsPersec;// bits per samples
  short  wBlockAlign; // block align
  short wBitsPerSample;   // bits per samples  16

  char dld[4];        //”data“
  int wSampleLength;  //data size  8
} ;  //44

class UDPForm : public QWidget
{
    Q_OBJECT
    
public:
    explicit UDPForm(QWidget *parent = 0);
    ~UDPForm();
    
private slots:
    void on_pushButton_clicked();
    void readPendingDatagrams();
    void on_pushButton_2_clicked();

private:
    Ui::UDPForm *ui;
    QUdpSocket *udpSocket;
    FILE *fp;
    char* buffer;
    int file_length;
    WAV_HEADER wav_header;
    int dataSizeIn20ms;
private:
    void initAlsaDevice();
};

#endif // UDPFORM_H

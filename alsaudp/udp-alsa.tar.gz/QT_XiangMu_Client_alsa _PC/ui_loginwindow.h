/********************************************************************************
** Form generated from reading UI file 'loginwindow.ui'
**
** Created: Wed Apr 12 09:23:41 2017
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINWINDOW_H
#define UI_LOGINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *Name_lineEdit;
    QLineEdit *Passwd_lineEdit_2;
    QPushButton *pushButton_1;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_0;
    QPushButton *pushButton_login;
    QPushButton *pushButton_cancel;
    QPushButton *pushButton_clear;
    QPushButton *pushButton_backspace;
    QPushButton *pushButton_tab;
    QPushButton *Register_button;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LoginWindow)
    {
        if (LoginWindow->objectName().isEmpty())
            LoginWindow->setObjectName(QString::fromUtf8("LoginWindow"));
        LoginWindow->resize(480, 272);
        centralwidget = new QWidget(LoginWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 4, 81, 16));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 33, 91, 16));
        Name_lineEdit = new QLineEdit(centralwidget);
        Name_lineEdit->setObjectName(QString::fromUtf8("Name_lineEdit"));
        Name_lineEdit->setGeometry(QRect(142, 0, 201, 23));
        Passwd_lineEdit_2 = new QLineEdit(centralwidget);
        Passwd_lineEdit_2->setObjectName(QString::fromUtf8("Passwd_lineEdit_2"));
        Passwd_lineEdit_2->setGeometry(QRect(142, 30, 201, 23));
        pushButton_1 = new QPushButton(centralwidget);
        pushButton_1->setObjectName(QString::fromUtf8("pushButton_1"));
        pushButton_1->setGeometry(QRect(40, 70, 86, 27));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(140, 70, 86, 27));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(260, 70, 86, 27));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(40, 110, 86, 27));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(140, 110, 86, 27));
        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(260, 110, 86, 27));
        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(40, 150, 86, 27));
        pushButton_8 = new QPushButton(centralwidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(140, 150, 86, 27));
        pushButton_9 = new QPushButton(centralwidget);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(260, 150, 86, 27));
        pushButton_0 = new QPushButton(centralwidget);
        pushButton_0->setObjectName(QString::fromUtf8("pushButton_0"));
        pushButton_0->setGeometry(QRect(40, 190, 86, 27));
        pushButton_login = new QPushButton(centralwidget);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));
        pushButton_login->setGeometry(QRect(380, 110, 86, 27));
        pushButton_cancel = new QPushButton(centralwidget);
        pushButton_cancel->setObjectName(QString::fromUtf8("pushButton_cancel"));
        pushButton_cancel->setGeometry(QRect(380, 190, 86, 27));
        pushButton_clear = new QPushButton(centralwidget);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));
        pushButton_clear->setGeometry(QRect(140, 190, 86, 27));
        pushButton_backspace = new QPushButton(centralwidget);
        pushButton_backspace->setObjectName(QString::fromUtf8("pushButton_backspace"));
        pushButton_backspace->setGeometry(QRect(260, 190, 86, 27));
        pushButton_tab = new QPushButton(centralwidget);
        pushButton_tab->setObjectName(QString::fromUtf8("pushButton_tab"));
        pushButton_tab->setGeometry(QRect(380, 150, 86, 27));
        Register_button = new QPushButton(centralwidget);
        Register_button->setObjectName(QString::fromUtf8("Register_button"));
        Register_button->setGeometry(QRect(380, 70, 86, 27));
        LoginWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LoginWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 480, 25));
        LoginWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(LoginWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        LoginWindow->setStatusBar(statusbar);

        retranslateUi(LoginWindow);

        QMetaObject::connectSlotsByName(LoginWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LoginWindow)
    {
        LoginWindow->setWindowTitle(QApplication::translate("LoginWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("LoginWindow", "User Name :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("LoginWindow", "User Passwd :", 0, QApplication::UnicodeUTF8));
        pushButton_1->setText(QApplication::translate("LoginWindow", "1", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("LoginWindow", "2", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("LoginWindow", "3", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("LoginWindow", "4", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("LoginWindow", "5", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("LoginWindow", "6", 0, QApplication::UnicodeUTF8));
        pushButton_7->setText(QApplication::translate("LoginWindow", "7", 0, QApplication::UnicodeUTF8));
        pushButton_8->setText(QApplication::translate("LoginWindow", "8", 0, QApplication::UnicodeUTF8));
        pushButton_9->setText(QApplication::translate("LoginWindow", "9", 0, QApplication::UnicodeUTF8));
        pushButton_0->setText(QApplication::translate("LoginWindow", "0", 0, QApplication::UnicodeUTF8));
        pushButton_login->setText(QApplication::translate("LoginWindow", "Login", 0, QApplication::UnicodeUTF8));
        pushButton_cancel->setText(QApplication::translate("LoginWindow", "Cancel", 0, QApplication::UnicodeUTF8));
        pushButton_clear->setText(QApplication::translate("LoginWindow", "Clear", 0, QApplication::UnicodeUTF8));
        pushButton_backspace->setText(QApplication::translate("LoginWindow", "Backspace", 0, QApplication::UnicodeUTF8));
        pushButton_tab->setText(QApplication::translate("LoginWindow", "Tab", 0, QApplication::UnicodeUTF8));
        Register_button->setText(QApplication::translate("LoginWindow", "Rigister", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class LoginWindow: public Ui_LoginWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINWINDOW_H

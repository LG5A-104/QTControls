/********************************************************************************
** Form generated from reading UI file 'my_mainwindow.ui'
**
** Created: Wed Apr 12 09:23:41 2017
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MY_MAINWINDOW_H
#define UI_MY_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_My_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QPushButton *Start_pushButton;
    QLabel *label_2;
    QLabel *rate;
    QLabel *label_3;
    QPushButton *ReStart_pushButton;
    QLabel *warning_label;
    QLabel *id_label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *My_MainWindow)
    {
        if (My_MainWindow->objectName().isEmpty())
            My_MainWindow->setObjectName(QString::fromUtf8("My_MainWindow"));
        My_MainWindow->resize(480, 272);
        centralwidget = new QWidget(My_MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(181, 56, 58, 13));
        Start_pushButton = new QPushButton(centralwidget);
        Start_pushButton->setObjectName(QString::fromUtf8("Start_pushButton"));
        Start_pushButton->setGeometry(QRect(380, 70, 86, 27));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 53, 71, 20));
        rate = new QLabel(centralwidget);
        rate->setObjectName(QString::fromUtf8("rate"));
        rate->setGeometry(QRect(100, 55, 61, 16));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(33, 92, 51, 21));
        ReStart_pushButton = new QPushButton(centralwidget);
        ReStart_pushButton->setObjectName(QString::fromUtf8("ReStart_pushButton"));
        ReStart_pushButton->setGeometry(QRect(380, 156, 86, 27));
        warning_label = new QLabel(centralwidget);
        warning_label->setObjectName(QString::fromUtf8("warning_label"));
        warning_label->setGeometry(QRect(70, 15, 281, 21));
        id_label = new QLabel(centralwidget);
        id_label->setObjectName(QString::fromUtf8("id_label"));
        id_label->setGeometry(QRect(110, 90, 71, 21));
        My_MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(My_MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 480, 25));
        My_MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(My_MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        My_MainWindow->setStatusBar(statusbar);

        retranslateUi(My_MainWindow);

        QMetaObject::connectSlotsByName(My_MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *My_MainWindow)
    {
        My_MainWindow->setWindowTitle(QApplication::translate("My_MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("My_MainWindow", "KHZ", 0, QApplication::UnicodeUTF8));
        Start_pushButton->setText(QApplication::translate("My_MainWindow", "Start", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("My_MainWindow", "My Rate :", 0, QApplication::UnicodeUTF8));
        rate->setText(QString());
        label_3->setText(QApplication::translate("My_MainWindow", "My ID :", 0, QApplication::UnicodeUTF8));
        ReStart_pushButton->setText(QApplication::translate("My_MainWindow", "ReStart", 0, QApplication::UnicodeUTF8));
        warning_label->setText(QString());
        id_label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class My_MainWindow: public Ui_My_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MY_MAINWINDOW_H

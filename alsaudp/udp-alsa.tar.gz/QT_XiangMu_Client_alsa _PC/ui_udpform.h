/********************************************************************************
** Form generated from reading UI file 'udpform.ui'
**
** Created: Thu Apr 13 10:11:15 2017
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UDPFORM_H
#define UI_UDPFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTextBrowser>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UDPForm
{
public:
    QPushButton *pushButton_2;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QTextBrowser *textBrowser;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QLineEdit *lineEdit;

    void setupUi(QWidget *UDPForm)
    {
        if (UDPForm->objectName().isEmpty())
            UDPForm->setObjectName(QString::fromUtf8("UDPForm"));
        UDPForm->resize(400, 300);
        pushButton_2 = new QPushButton(UDPForm);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(10, 250, 191, 27));
        layoutWidget = new QWidget(UDPForm);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 258, 229));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        textBrowser = new QTextBrowser(layoutWidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        verticalLayout->addWidget(textBrowser);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout->addWidget(pushButton);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        horizontalLayout->addWidget(lineEdit);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(UDPForm);

        QMetaObject::connectSlotsByName(UDPForm);
    } // setupUi

    void retranslateUi(QWidget *UDPForm)
    {
        UDPForm->setWindowTitle(QApplication::translate("UDPForm", "Form", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("UDPForm", "UDP send wav", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("UDPForm", "SendUDP", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class UDPForm: public Ui_UDPForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UDPFORM_H

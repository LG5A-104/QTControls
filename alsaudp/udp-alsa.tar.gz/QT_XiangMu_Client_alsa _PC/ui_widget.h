/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created: Wed Apr 12 09:23:41 2017
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label;
    QLabel *Date_label;
    QPushButton *Get_int_system;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(480, 272);
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 80, 79, 29));
        Date_label = new QLabel(Widget);
        Date_label->setObjectName(QString::fromUtf8("Date_label"));
        Date_label->setGeometry(QRect(160, 80, 301, 31));
        Get_int_system = new QPushButton(Widget);
        Get_int_system->setObjectName(QString::fromUtf8("Get_int_system"));
        Get_int_system->setGeometry(QRect(175, 203, 121, 27));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "audibly recite ", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "Date Time :", 0, QApplication::UnicodeUTF8));
        Date_label->setText(QString());
        Get_int_system->setText(QApplication::translate("Widget", "Get In System", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H

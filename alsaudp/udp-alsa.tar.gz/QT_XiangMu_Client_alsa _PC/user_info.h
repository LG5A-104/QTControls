#ifndef USER_INFO_H
#define USER_INFO_H
#include <iostream>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/un.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h>
#include <errno.h>
#include<pthread.h>
#include<netinet/tcp.h>

#define Message_length 512
#define Command_length 25

using namespace std;

struct d_flags
{
    int flags;
    int length;
    char buff[Command_length];
};

struct Cli_Message   //数据缓冲区
{
    int adc_data;                      //adc的值
    unsigned int  client_number;	 //客户端的编号
    unsigned char buff[Message_length];      //声音
};


//unsigned char read_sound_buff[1024*64];
//unsigned char write_sound_buff[1024*64];
#define LENGTH 5   /* 存储秒数 */
#define RATE 8000  /* 采样频率 */
#define SIZE 8     /* 量化位数 */
#define CHANNELS 1  /* 声道数目 */

#endif // USER_INFO_H

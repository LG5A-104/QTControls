#include "widget.h"
#include "ui_widget.h"
#include<QTimer>
#include<QTime>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    login=new LoginWindow;
    QObject::connect(ui->Get_int_system,SIGNAL(clicked()),this,SLOT(Get_In_System()));
    QTimer *time=new QTimer;
    time->start(1000);
    QObject::connect(time,SIGNAL(timeout()),this,SLOT(SetTime()));

}
void Widget::SetTime()
{
    QDateTime time = QDateTime::currentDateTime();
    //获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd  hh:mm:ss  dddd");
    //设置系统时间显示格式
    ui->Date_label->setText(str);
    //在标签上显示时间
}
void Widget::Get_In_System()
{
    login->showFullScreen();
}

Widget::~Widget()
{
    delete ui;
}

#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
//`#include"loginwindow.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
public slots:
    void Get_In_System(void);
    void SetTime(void);

private:
    Ui::Widget *ui;

    LoginWindow *login;
};

#endif // WIDGET_H

#include "playpcm.h"
#include<QDebug>

PlayPCM::PlayPCM():
    m_Buffer(new QByteArray())
{

    b_stop=false;
    playNum = 0;
}

PlayPCM::~PlayPCM()
{
    delete m_Buffer;
    delete playback_handle;
}

void PlayPCM::run()
{
    while(!b_stop)
    {
        QMutexLocker locker(&m_mutex);

        if(m_Buffer->size()>=dataSizeIn)
        {


            playNum ++;
            QByteArray bytes=m_Buffer->mid(0,dataSizeIn);
            int err;
            qDebug() << tr("udp Play wav,snd_pcm_writei")<< QString::number(playNum);
            qDebug() << tr("m_Buffer size:")<< QString::number(m_Buffer->size());
            //qDebug() << tr("bytes size:")<< QString::number(bytes.size());

            //if ((snd_pcm_writei (playback_handle, datagram.data(), file_length/wav_header.wBlockAlign)) != file_length/wav_header.wBlockAlign) {
//            if ((err = snd_pcm_writei (playback_handle, bytes.data(), 880)) != 880) {
//                qDebug() << tr("write to audio interface failed \n");
//                //snd_pcm_prepare (playback_handle);
//                snd_pcm_recover(playback_handle, err, 0);
//            }
            while ((err = snd_pcm_writei(playback_handle, bytes.data(), 882)) < 0) {
                    snd_pcm_prepare(playback_handle);
                    qDebug() << tr("write to audio interface failed \n");
            }
            m_Buffer->remove(0,dataSizeIn);
        }
        else if(!m_Buffer->isEmpty())
        {
            qDebug()<<"m_Buffer.size  <  dataSizeIn";

            qDebug()<<"m_Buffer->size:"<<m_Buffer->size();


            qDebug()<<"m_Buffer not Empty,clear ";
            m_Buffer->clear();
        }

        //usleep(5000);
    }



}

void PlayPCM::appendBuffer(QByteArray pcm_receive)
{
    QMutexLocker locker(&m_mutex);
    m_Buffer->append(pcm_receive);
}

//dataSizeIn
void PlayPCM::getFrameLen(int len)
{
    dataSizeIn = len;
    qDebug() << tr("dataSizeIn:")<< QString::number(dataSizeIn);
}

//frameNum
int PlayPCM::getFrameNum(int Num)
{
    m_frameNum = Num;
    qDebug() << tr("m_frameNum:")<< QString::number(m_frameNum);
    return m_frameNum;
}

//playback_handle
snd_pcm_t * PlayPCM::getPcmHandle(snd_pcm_t *handle)
{
    //#include <alsa/asoundlib.h>
    playback_handle = handle;
    return playback_handle;
}

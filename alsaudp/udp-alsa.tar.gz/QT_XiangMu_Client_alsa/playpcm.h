#ifndef PLAYPCM_H
#define PLAYPCM_H

#include <QThread>
#include <QMutex>
#include <alsa/asoundlib.h>

class PlayPCM : public QThread
{
public:
    PlayPCM();
    ~PlayPCM();

    void appendBuffer(QByteArray pcm_receive);
    void getFrameLen(int len);
    int getFrameNum(int Num);
    snd_pcm_t * getPcmHandle(snd_pcm_t *handle);

    void run();

    bool b_stop;

private:

    QByteArray* m_Buffer;
    int dataSizeIn;
    int m_frameNum;
    QMutex  m_mutex;
    snd_pcm_t *playback_handle;
    int playNum;

};

#endif // PLAYPCM_H

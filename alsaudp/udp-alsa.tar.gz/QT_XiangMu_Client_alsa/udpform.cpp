#include "udpform.h"

UDPForm::UDPForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UDPForm)
{
    ui->setupUi(this);
    m_playPcm=new PlayPCM();

    initAlsaDevice();
    udpSocket = new QUdpSocket();
    udpSocket->bind(13930, QUdpSocket::ShareAddress);
    //udpSocket->bind(13930, QUdpSocket::DontShareAddress);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readPendingDatagrams()));


}

UDPForm::~UDPForm()
{
    delete ui;
    delete buffer;
}

void UDPForm::on_pushButton_clicked()
{
     // QString data = tr("alsa project to network");
//    QString data = ui->lineEdit->text();
//    QHostAddress adr=QHostAddress("192.168.9.179");
    //  udpSocket->writeDatagram(data.toUtf8(), adr, 13930);
    //qDebug() << QHostAddress::Broadcast;
    //udpSocket->writeDatagram(data.toUtf8(), QHostAddress::LocalHost, 13930);

     m_playPcm->start();
     qDebug() << tr("pcm thread run");

}

void UDPForm::readPendingDatagrams()
{
    numFrame++;
    while (udpSocket->hasPendingDatagrams()) {
    //while (m_Buffer->count()>0) {
           QByteArray datagram;
           // 不会存在粘包问题
           // pendingDatagramSize() returns the size of the first pending UDP datagram.
           // If there is no datagram available, this function returns -1.

               datagram.resize(udpSocket->pendingDatagramSize());
               udpSocket->readDatagram(datagram.data(), datagram.size());

               //m_Buffer->append(datagram);
               m_playPcm->appendBuffer(datagram);




//           QByteArray bytes=m_Buffer->mid(0,dataSizeIn20ms);
//           m_Buffer->remove(0,dataSizeIn20ms);/

           //qDebug() << QString::fromUtf8(datagram);
           //ui->textBrowser->append(QString::number(numFrame));
           //qDebug() << tr("udp Play wav,snd_pcm_writei");
           //if ((snd_pcm_writei (playback_handle, datagram.data(), file_length/wav_header.wBlockAlign)) != file_length/wav_header.wBlockAlign) {
           //if ((snd_pcm_writei (playback_handle, bytes.data(), file_length/wav_header.wBlockAlign)) != file_length/wav_header.wBlockAlign) {
           //qDebug() << tr("write to audio interface failed \n");
               //snd_pcm_prepare (playback_handle);
               //snd_pcm_recover(playback_handle, err, 0);
               //continue ;

    }
}

void UDPForm::initAlsaDevice()
{
      int err;
      unsigned int exact_rate; /* Sample rate returned by */
      file_length = 0;
      dataSizeIn20ms = 0;
      numFrame = 0;
      /* Handle for the PCM device */
      //snd_pcm_t *playback_handle;
      /* Playback stream */
      snd_pcm_stream_t stream = SND_PCM_STREAM_PLAYBACK;
      /* This structure contains information about the hardware and can be used to specify the configuration to be used for */
      /* the PCM stream. */
      snd_pcm_hw_params_t *hw_params;
      /* Name of the PCM device, like plughw:0,0 */
      /* The first number is the number of the soundcard, the second number is the number of the device. */
      static char *device = "default"; /* playback device */

      fp = fopen("dengziqi.wav","rw");
      if (NULL == fp ) {
            qDebug() <<tr("Error:open %s erro ,please check the WAV-File exist?\n");
            return ;/* code */
        }
      memset(&wav_header,0,sizeof(struct WAV_HEADER));
      file_length = fread(&wav_header, 1, sizeof(wav_header), fp);
      /* Open PCM. The last parameter of this function is the mode. */
      if ((err = snd_pcm_open (&playback_handle, device, stream, 0)) < 0) {
          qDebug()<< tr("cannot open audio device\n");
            return;
      }

      /* Allocate the snd_pcm_hw_params_t structure on the stack. */
      if ((err = snd_pcm_hw_params_malloc (&hw_params)) < 0) {
          qDebug()<< tr("cannot allocate hardware parameters \n");
          return ;
      }

      /* Init hwparams with full configuration space */
      if ((err = snd_pcm_hw_params_any (playback_handle, hw_params)) < 0) {
          qDebug()<< tr("cannot initialize hardware parameter structure \n");
          return ;
      }

        /* Set access type. */
      if ((err = snd_pcm_hw_params_set_access (playback_handle, hw_params, SND_PCM_ACCESS_RW_INTERLEAVED)) < 0) {
          qDebug()<< tr("cannot set access type \n");
          return ;
      }

      /* Set sample format */
     // printf("wav_header.wBitsPerSample = %d\n", wav_header.wBitsPerSample);
      switch (wav_header.wBitsPerSample/8-1) {
        case 0:
          if ((err = snd_pcm_hw_params_set_format (playback_handle, hw_params, SND_PCM_FORMAT_U8)) < 0) {
              //fprintf (stderr, "cannot set sample format (%s)\n", snd_strerror (err));
              return;
          }
          break;
        case 1:
          if ((err = snd_pcm_hw_params_set_format (playback_handle, hw_params, SND_PCM_FORMAT_S16_LE)) < 0) {
              //fprintf (stderr, "cannot set sample format (%s)\n", snd_strerror (err));
              return ;
          }
          break;
        case 2:
          if ((err = snd_pcm_hw_params_set_format (playback_handle, hw_params, SND_PCM_FORMAT_S24_LE)) < 0) {
              //fprintf (stderr, "cannot set sample format (%s)\n", snd_strerror (err));
              return ;
          }
          break;
        default:
          //printf("wav_header.wBitsPerSample read error wav_header.wBitsPerSample/8-1 = %d \n",wav_header.wBitsPerSample/8-1);
          return ;
      }

      exact_rate = wav_header.nSamplesPersec;
      //printf("wav_header.nSamplesPersec = %d\n", wav_header.nSamplesPersec);
      if ((err = snd_pcm_hw_params_set_rate_near (playback_handle, hw_params, &exact_rate, 0)) < 0) {
         // fprintf (stderr, "cannot set sample rate (%s)\n", snd_strerror (err));
          return ;
      }

      if (wav_header.nSamplesPersec != exact_rate) {
          //fprintf(stderr, "The wav_header.nSamplesPersec %d Hz is not supported by your hardware.\n ==> Using %d Hz instead.\n", wav_header.nSamplesPersec, exact_rate);
      }

      /* Set number of channels */
      if ((err = snd_pcm_hw_params_set_channels (playback_handle, hw_params, wav_header.wChannels)) < 0) {
          //fprintf (stderr, "cannot set channel count (%s)\n", snd_strerror (err));
          return ;
      }
      /* Apply HW parameter settings to PCM device and prepare device. */
      if ((err = snd_pcm_hw_params (playback_handle, hw_params)) < 0) {
          //fprintf (stderr, "cannot set parameters (%s)\n", snd_strerror (err));
          return ;
      }

      snd_pcm_hw_params_free (hw_params);

      if ((err = snd_pcm_prepare (playback_handle)) < 0) {
          //fprintf (stderr, "cannot prepare audio interface for use (%s)\n", snd_strerror (err));
          return;
      }

      /*malloc wav pcm data buffer*/
      dataSizeIn20ms = exact_rate * wav_header.wBlockAlign / 50;
      m_playPcm->getFrameLen(dataSizeIn20ms);
      m_playPcm->getFrameNum(file_length/wav_header.wBlockAlign);
      m_playPcm->getPcmHandle(playback_handle);
      //printf("dataSizeIn20ms = %d\n",dataSizeIn20ms);
      buffer =(char*)malloc(dataSizeIn20ms);

      fclose(fp);
}

void UDPForm::on_pushButton_2_clicked()
{ 
    int err;
    fp = fopen("dengziqi.wav","rw");
    if (NULL == fp ) {
          qDebug() <<tr("Error:open %s erro ,please check the WAV-File exist?\n");
          return ;/* code */
      }
    memset(&wav_header,0,sizeof(struct WAV_HEADER));
    file_length = fread(&wav_header, 1, sizeof(wav_header), fp);
    /* seek to the sound data position */
    fseek(fp, sizeof(wav_header), SEEK_SET);

    while(file_length)
    {
      memset(buffer, 0, dataSizeIn20ms);
      file_length = fread(buffer, 1, dataSizeIn20ms, fp);
      usleep(20);
      qDebug() << tr("snd_pcm_writei");
      /* Write some junk data to produce sound. */
      if ((err = snd_pcm_writei (playback_handle, buffer, file_length/wav_header.wBlockAlign)) != file_length/wav_header.wBlockAlign) {
          qDebug() << tr("write to audio interface failed \n");
          snd_pcm_prepare (playback_handle);
          snd_pcm_recover(playback_handle, err, 0);
          continue ;
      }
      qDebug() << tr("dataSizeIn20ms")<<QString::number(dataSizeIn20ms);
      qDebug() << tr("file_length/wav_header.wBlockAlign")<<QString::number(file_length/wav_header.wBlockAlign);
    }
    //fprintf (stdout, "audio PLAY successful\n");
    //snd_pcm_close (playback_handle);
}
